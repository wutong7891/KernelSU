#!/system/bin/sh
MODDIR=${0%/*}

#放到后台执行，不阻塞系统开机
(
sh ${MODDIR}/run.sh
sleep 8
sh ${MODDIR}/run.sh
) &