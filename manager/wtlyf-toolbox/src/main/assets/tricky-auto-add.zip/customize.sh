SKIPUNZIP=0

if [ ! -f "/data/adb/tricky_store/target.txt" ]; then
  abort "未检测到TS配置，安装退出！"
fi

ui_print "说明："
ui_print "① 模块只是自动添加TS列表，不提供额外隐藏功能！"
ui_print "② 只要安装完成就会将所有第三方应用添加至TS列表"
ui_print "③ 新安装应用自动添加列表功能需要在模块安装完成后重启一次手机(或平板)才生效。"
ui_print ""

chmod 0755 "$MODPATH/weix-ts"
chmod 0755 "$MODPATH/boot-completed.sh"

"$MODPATH/boot-completed.sh" i

ui_print "模块安装完成！"
ui_print ""
ui_print ""
