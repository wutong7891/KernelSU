#!/system/bin/sh

MODDIR=${0%/*}

core="$MODDIR/weix-ts"
script="$MODDIR/boot-completed.sh"

user_dir='/data/user/0'
ts_config='/data/adb/tricky_store/target.txt'
base_pkg="
  com.android.vending
  com.google.android.gms
  com.google.android.gsf
  com.heytap.speechassist
  com.coloros.sceneservice
  com.oplus.deepthinker
"

add_ts_config() {
  tmp="$(mktemp 2>/dev/null || echo "$MODDIR/tmp")"
  if [ -n "$1" ]; then
    if ! grep -q "$1" "$ts_config"; then
      awk -v pkg="$1" '
        BEGIN {
          inserted=0
        }
        {
          if (!inserted && pkg < $0) {
            print pkg
            inserted=1
          }
          print
        }
        END {
          if (!inserted) print pkg
        }
      ' "$ts_config" >"$tmp" && mv "$tmp" "$ts_config"
    fi
  else
    tsc_status="$([ -s "$ts_config" ] && echo 1 || echo 0)"
    {
      echo "$(
        pm list packages -s 2>/dev/null |
          awk -F ':' -v base="$(echo "$base_pkg" | tr '\n' '|')" '
          BEGIN {
            split(base, pkg, "|")
            for (i in pkg) {
              sub(/ +/, "", pkg[i])
              if (pkg[i] != "") map[pkg[i]]
            }
          }
          $2 in map {
            print ":"$2
          }
        '
      )"
      pm list packages -3 2>/dev/null
    } |
      awk -F ':' -v tsc_stat="$tsc_status" '
      FNR == NR && tsc_stat == 1 {
        line = pkg = $0
        sub(/[\r!?]+$/, "", pkg)
        if (pkg != "") map[pkg] = line
        next
      }
      !($2 in map) {
        map[$2] = $2
      }
      END {
        for (pkg in map) print map[pkg]
      }
    ' "$ts_config" - | sort >"$tmp" && mv "$tmp" "$ts_config"
  fi
}

start_monitor() {
  ps -eo cmd | grep -qx "weix-ts" && exit 0
  "$core" "$script" "$user_dir" &
}

if [ "$1" = "i" ]; then
  add_ts_config
  exit
fi

if [ "$#" -eq 1 ]; then
  add_ts_config "$1"
  exit
fi

add_ts_config
start_monitor
exit
