#!/system/bin/sh

resetprop -n -d ro.boot.selinux
